<link rel="shortcut icon" type="image/x-icon" href="assets/images/fav.png" />
<title>Guruvignesh</title>
<link rel="stylesheet preload" href="assets/css/plugins/fontawesome.css" as="style" />
<link rel="stylesheet preload" href="assets/css/plugins/swiper.css" as="style" />
<link rel="stylesheet preload" href="assets/css/plugins/metismenu.css" as="style" />
<link rel="stylesheet preload" href="assets/css/plugins/magnifying-popup.css" as="style" />
<link rel="stylesheet preload" href="assets/css/plugins/odometer.css" as="style" />
<link rel="stylesheet preload" href="assets/css/vendor/bootstrap.min.css" as="style" />

<link rel="preconnect" href="https://fonts.googleapis.com/" />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&amp;family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&amp;display=swap" rel="stylesheet preload" as="style" />
<link rel="preload" as="image" href="assets/images/banner/21.webp" />
<link rel="stylesheet preload" href="assets/css/style.css" as="style" />

<link rel="stylesheet preload" href="assets/css/app.css" as="style" />