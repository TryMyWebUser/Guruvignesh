<div id="side-bar" class="side-bar header-two">
    <button class="close-icon-menu" title="Close menu"><i class="far fa-times"></i></button>
    <!-- inner menu area desktop start -->
    <div class="rts-sidebar-menu-desktop">
        <a class="logo-1" href="index.php">
            <!-- <img class="logo" src="assets/images/logo/01.svg" alt="finbiz_logo" /> -->
            <h4 class="text-dark fs-1 mt-5">Guruvignesh</h4>
        </a>
        <!-- <div class="body d-none d-xl-block">
            <p class="disc">
                We must explain to you how all seds this mistakens idea denouncing pleasures and praising account. All seds this mistakens idea denouncing pleasures.
            </p>
            <div class="get-in-touch">
                <div class="h6 title">Get In Touch</div>
                <div class="wrapper">
                    <div class="single">
                        <i class="fas fa-phone-alt"></i>
                        <a href="#">+8801234566789</a>
                    </div>
                    <div class="single">
                        <i class="fas fa-envelope"></i>
                        <a href="#">example@gmail.com</a>
                    </div>
                    <div class="single">
                        <i class="fas fa-globe"></i>
                        <a href="#">www.webexample.com</a>
                    </div>
                    <div class="single">
                        <i class="fas fa-map-marker-alt"></i>
                        <a href="#">13/A, New Pro State, NYC</a>
                    </div>->
                </div>
                <div class="social-wrapper-two menu">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div> -->
    </div>
    <!-- mobile menu area start -->
    <div class="mobile-menu d-block d-xl-none">
        <nav class="nav-main mainmenu-nav mt--30">
            <ul class="mainmenu metismenu" id="mobile-menu-active">
                <li>
                    <a href="index.php" class="main text-dark" aria-expanded="false">Home</a>
                </li>
                <li>
                    <a href="#" class="main text-dark" aria-expanded="false">About Us</a>
                </li>
                <!-- <li class="has-droupdown">
                    <a href="#" class="main" aria-expanded="false">Pages</a>
                    <ul class="submenu mm-collapse" style="height: 0px;">
                        <li><a href="about.html">About Company</a></li>
                        <li><a href="service.html">Service</a></li>
                        <li><a href="service-details.html">Service Details</a></li>
                        <li><a href="service-details-2.html">Service Details 2</a></li>
                        <li><a href="project.html">Project</a></li>
                        <li><a href="team.html">Team</a></li>
                        <li><a href="team-details.html">Team Details</a></li>
                        <li><a href="pricing.html">Pricing</a></li>
                        <li><a href="appoinment.html">Appoinment</a></li>
                        <li><a href="history.html">Our History</a></li>
                        <li><a href="blog-list.html">Blog List</a></li>
                        <li><a href="blog-grid.html">Blog List</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                        <li><a href="blog-details-2.html">Blog Details 02</a></li>
                        <li><a href="faq.html">Faq's</a></li>
                        <li><a href="career.html">Career</a></li>
                        <li><a href="our-mission.html">Our Mission</a></li>
                        <li><a href="partners.html">Partners</a></li>
                    </ul>
                </li> -->
                <li>
                    <a href="#" class="main text-dark" aria-expanded="false">Services</a>
                    <!-- <ul class="submenu mm-collapse" style="height: 0px;">
                        <li><a class="mobile-menu-link" href="service.html">Service</a></li>
                        <li><a class="mobile-menu-link" href="service-details.html">Service Details</a></li>
                        <li><a class="mobile-menu-link" href="service-details-2.html">Service Details 2</a></li>
                        <li><a class="mobile-menu-link" href="service-details-3.html">Service Details 3</a></li>
                        <li><a class="mobile-menu-link" href="service-details-4.html">Service Details 4</a></li>
                        <li><a class="mobile-menu-link" href="service-details-5.html">Service Details 5</a></li>
                    </ul> -->
                </li>
                <li> <!-- class="has-droupdown" -->
                    <a href="#" class="main text-dark" aria-expanded="false">Blog</a>
                    <!-- <ul class="submenu mm-collapse">
                        <li><a href="blog-grid.html">Blog Grid</a></li>
                        <li><a href="blog-list.html">Blog List</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                        <li><a href="blog-details-2.html">Blog Details 2</a></li>
                    </ul> -->
                </li>
                <li>
                    <a href="#" class="main text-dark" aria-expanded="false">Contact Us</a>
                </li>
            </ul>
        </nav>

        <div class="social-wrapper-one">
            <ul>
                <li>
                    <a href="#" aria-label="Facebook">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                </li>
                <li>
                    <a href="#" aria-label="instagram">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                </li>
                <li>
                    <a href="#" aria-label="whatsapp">
                        <i class="fa-brands fa-whatsapp"></i>
                    </a>
                </li>
                <li>
                    <a href="#" aria-label="youtube">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- mobile menu area end -->
</div>
<!-- inner menu area desktop End -->

<!-- offcanvase search -->
<div class="search-input-area">
    <div class="container">
        <div class="search-input-inner">
            <div class="input-div">
                <input class="search-input autocomplete" type="text" placeholder="Search by keyword or #" />
                <button><i class="far fa-search"></i></button>
            </div>
        </div>
    </div>
    <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
</div>
<div id="anywhere-home" class=""></div>

<!-- rtl btn area start -->
<div class="rtl-ltr-switcher-btn">
    <span class="rtl show">View RTL</span>
    <span class="ltr">View LTR</span>
</div>
<!-- rtl btn area end -->

<!-- progress area start -->
<div class="progress-wrap">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
    </svg>
</div>
<!-- progress area end -->

<script defer src="assets/js/plugins/jquery.js"></script>

<script defer src="assets/js/plugins/odometer.js"></script>
<script defer src="assets/js/plugins/jquery-appear.js"></script>

<script defer src="assets/js/plugins/gsap.js"></script>
<script defer src="assets/js/plugins/split-text.js"></script>
<script defer src="assets/js/plugins/scroll-trigger.js"></script>
<script defer src="assets/js/plugins/smooth-scroll.js"></script>
<script defer src="assets/js/plugins/metismenu.js"></script>
<script defer src="assets/js/plugins/popup.js"></script>

<script defer src="assets/js/vendor/bootstrap.min.js"></script>
<script defer src="assets/js/plugins/swiper.js"></script>
<script defer src="assets/js/plugins/contact.form.js"></script>

<script defer src="assets/js/main.js"></script>